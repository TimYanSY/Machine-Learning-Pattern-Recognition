clc;
clear all;
x2=-3:0.1:3;
y2=(x2<0).*0 + (x2>=0).*exp(-x2);
plot(x2,y2);
hold on;
axis([-3 3 -1 1]); 
xlabel('x');
ylabel('p(x|\theta)');

