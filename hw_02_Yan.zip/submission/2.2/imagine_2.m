clc;
clear all;
x2=0:0.1:5;
y2=(x2>=0).*x2.*exp(-2*x2);
plot(x2,y2);
hold on;
xlabel('\theta');
ylabel('p(x|\theta)');