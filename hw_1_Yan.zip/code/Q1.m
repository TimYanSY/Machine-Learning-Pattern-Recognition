double x=;
x=-3:0.01:3;
double y;
y=2*exp(-abs(x)+abs(x-1)/2);
plot(x,y);
xlabel('x');
ylabel('y');
title('likelihood ratio when a1=0, b1=1, a2=1, b2=2');
grid on;