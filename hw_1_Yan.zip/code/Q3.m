function [datasamples, classindex]=Q3(mu, sigma, nSamples, prior)
%this function is for question 3, 2-dimention
%   this is the detail
array=[1:nSamples];
classindex=zeros(nSamples,1);
for i=1:nSamples
rm=rand(1);
if(rm<=prior(1))
    classindex(i,1)=1;
else
    classindex(i,1)=2; 
end
end
datasamples=zeros(nSamples,2);
k=1;
j=1;
for(i=1:nSamples)
    
        if(classindex(i)==1)
        d=mvnrnd(mu{1},sigma{1,1},1);
        x=d(:,1);
        y=d(:,2);
        datasamples(i,1)=x;
        datasamples(i,2)=y;
        datasamples1(k,1)=x;
        datasamples1(k,2)=y;
        k=k+1;
        
        elseif(classindex(i)==2)
        d=mvnrnd(mu{2},sigma{1,2},1);
        x=d(:,1);
        y=d(:,2);
        datasamples(i,1)=x;
        datasamples(i,2)=y;
        datasamples2(j,1)=x;
        datasamples2(j,2)=y;
        j=j+1;
        end
        
end
plot(datasamples1(:,1),datasamples1(:,2),'r+');
hold on;
plot(datasamples2(:,1),datasamples2(:,2),'*');
xlabel('x');
ylabel('y');
legend('class one','class two');
grid on;
end
% mu{1}=[0;0];
% mu{2}=[3;3];
% sigma{1}=[1,0;0,1];
% sigma{2}=[1,0;0,1];
% prior(1)=0.5;
% prior(2)=0.5;
% nSamples=400;
% n1=zeros(nSamples,2);
% n2=zeros(nSamples,1);
% [n1,n2]=Q3(mu,sigma,nSamples,prior)