function [ datag ] = Q42( mu, sigma, nSamples, prior  )
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
array=[1:nSamples];
classindex=zeros(nSamples,1);
for i=1:nSamples
    rm=rand(1);
    if(rm<=prior(1))
        classindex(i,1)=1
    else
        classindex(i,1)=2
    end
end
datag=zeros(nSamples,2);
datasamples=zeros(nSamples,2);
ct1=0;
ct11=0;
ct2=0;
ct22=0;
k=1;
j=1;
w1=inv(sigma{1})*mu{1};
w2=inv(sigma{2})*mu{2};
w10=(-0.5)*mu{1}'*inv(sigma{1})*mu{1}+log(prior(1));
w20=(-0.5)*mu{2}'*inv(sigma{2})*mu{2}+log(prior(2));
for(i=1:nSamples)
        if(classindex(i)==1)
        d=mvnrnd(mu{1},sigma{1},1);
        x=d(:,1);
        y=d(:,2);
        datasamples(i,1)=x;
        datasamples(i,2)=y;
        datasamples1(k,1)=x;
        datasamples1(k,2)=y;
        k=k+1;
        datag(i,1)=w1'*[x;y]+w10;
        datag(i,2)=w2'*[x;y]+w20;
        if datag(i,1)-datag(i,2)>=0
            ct1=ct1+1;
            ct11=ct11+1;
        elseif datag(i,1)-datag(i,2)<0
             ct1=ct1+1;
        end
        
        elseif(classindex(i)==2)
        d=mvnrnd(mu{2},sigma{2},1);
        x=d(:,1);
        y=d(:,2);
        datasamples(i,1)=x;
        datasamples(i,2)=y;
        datasamples2(j,1)=x;
        datasamples2(j,2)=y;
        j=j+1;
        datag(i,1)=w1'*[x;y]+w10;
        datag(i,2)=w2'*[x;y]+w20;
        if datag(i,1)-datag(i,2)>=0
            ct2=ct2+1;
        elseif datag(i,1)-datag(i,2)<0
             ct2=ct2+1;
             ct22=ct22+1;
        end
        end
        
end
plot(datasamples1(:,1),datasamples1(:,2),'r+');
hold on;
plot(datasamples2(:,1),datasamples2(:,2),'b*');
hold on;
accuracy1=ct11/(ct1);
accuracy2=ct22/(ct2);
accuracy=(ct11+ct22)/nSamples;
c1=ct1;
c11=ct11;
c2=ct2;
c22=ct22;
syms aa;
syms bb;
ezplot((w1'*[aa;bb]+w10)-(w2'*[aa;bb]+w20));
xlabel('x');
ylabel('y');
title(['accuracy = ' num2str(accuracy)]);
legend('class one','class two');
end
% mu{1}=[0;0];
% mu{2}=[2;2];
% sigma{1}=[2,-0.7;-0.7,3];
% sigma{2}=[2,-0.7;-0.7,3];
% prior(1)=0.05;
% prior(2)=0.95;
% nSamples=400;
% n1=zeros(nSamples,2);
% [n1]=Q42(mu,sigma,nSamples,prior)

