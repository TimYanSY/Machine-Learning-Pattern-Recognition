x1=-5:0.01:5;
y1=(1/sqrt(2*pi))*exp(-0.5*x1.^2);
x2=-5:0.01:5;
y2=(1/(2*sqrt(pi)))*exp((-1/4)*(x2-1).^2);
y11=y1./(y1+y2);
y22=y2./(y1+y2);
plot(x1,y11);
hold on;
plot(x2,y22);
hold on;
x=solve('(1/sqrt(2*pi))*exp(-0.5*x^2)-((1/(2*sqrt(pi)))*exp((-1/4)*(x-1)^2))=0','x');
plot([x(1),x(1)],ylim,'--');
hold on;
plot([x(2),x(2)],ylim,'--');
hold on;
xlabel('x');
ylabel('y');
title('posterior probabilities p(w1|x) p(w2|x)');
legend('class one','class two');
text(-1,0.2,'R1','FontSize',18);
text(-4,0.2,'R2','FontSize',18);
text(3,0.2,'R2','FontSize',18);
grid on;
y=(1/sqrt(2*pi))*exp(-0.5*x.^2)
y=(1/(2*sqrt(pi)))*exp((-1/4)*(x-1).^2)