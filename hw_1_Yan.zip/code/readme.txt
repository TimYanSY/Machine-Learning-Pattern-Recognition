Before calling function Q3,Q41,Q42,Q43, please insert data in command line.
Q41 is for case I
Q42 is for case II
Q43 is for case III